from flask import Flask, request
import os
import socket
import datetime

app = Flask(__name__)

@app.route("/")
def hello():

    html = "<h3>Hello visitor!</h3>" \
           "You're accessing to a {name}<br/><br/>" \
           "<b>Hostname:</b> {hostname}<br/>" \
           "<b>Local Date/Time:</b> {lDateTime}<br/>" \
           "<b>Visitor IP:</b> {visIP}<br/>" \
	   "<b>Visitor OS:</b> {visPlat}<br/>" \
           "<b>Visitor browser:</b> {visBr} (Ver. {visVer})<br/>"
    return html.format(name=os.getenv("NAME", "world"), hostname=socket.gethostname(), lDateTime=str(datetime.datetime.now()),visIP=request.environ.get('HTTP_X_REAL_IP', request.remote_addr), visPlat=request.user_agent.platform, visBr=request.user_agent.browser, visVer=request.user_agent.version)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80)

