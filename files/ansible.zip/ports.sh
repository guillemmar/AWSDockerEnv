#! /bin/bash
#
echo "Path                                      Port"
for i in $(sudo netstat -tapun | grep LISTEN | awk '{print $4"-"$7}' | cut -d'/' -f1); do
  tmp=$(echo $i | cut -d'-' -f2)
  ppath=$(ps up $tmp | awk '{print $11}')
  ppath=$(echo $ppath | cut -d' ' -f2)
  ppath=$ppath.'.........................................................'
  tmp=$(echo $i | cut -d'-' -f1 | awk -F':' ' { print $NF }')
  echo ${ppath:0:41}.$tmp
done
