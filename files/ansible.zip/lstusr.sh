#! /bin/bash
#
echo "User                      Logged On"
for i in $(cat /etc/passwd | cut -d: -f1); do
  if [ "$(who | grep $i)" != '' ]
   then
     logged='Yes'
   else
     logged='No'
   fi
   i=$i"........................................"
   echo "${i:0:26}$logged"
   #echo
done
